(function($) {
    "use strict"

    new dlabSettings({
        version: "light"
    });


})(jQuery);