import socket from "./socket.js";


$(document).ready(function() {

    $('[data-toggle="tooltip"]').tooltip();

    $.fn.change_status = function (data,status) {
        return this.each(function () {

            let jtitle;
            let jbtn;
            let comment;
            let noty_body;

            if(status == 1){
                //init task
                jtitle = 'Está seguro de iniciar la tarea'
                jbtn = 'Iniciar';
                comment = '';
                noty_body = 'Se esta trabajando en la filial ';
            }else{
                //stop task
                jtitle = 'Está seguro de Finalizar la tarea';
                jbtn = 'Finalizar';
                comment = '<textarea id="mdl_comment" placeholder="Agregar Comentario" class="swal2-input form-control form-control-lg mt-3" style="height:150px;background: #e7e7e7;" ></textarea>';
                noty_body = 'Tarea Finalizada filial ';

            }

            // console.log(data)
            Swal.fire({
                position: 'center-center',
                title: 'Ejecutar Tarea',
                html: `¿${jtitle}?<br>
                     <br>Filial: <b>${data.f_name}</b>
                     <br>Piso: <b>${data.fr_name}</b>
                     <br>Estado Actual: <b>${data.s_name}</b>
                     <br>Tiempo Estimado: <b>${data.a_time} Minutos</b>
                     ${comment}
                    `,
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: jbtn,
                cancelButtonText: 'Cancelar',

            }).then((result) => {
                if (result.value) {

                    const dataR = {
                        name: data.f_name,
                        filial: data.f_id,
                        assigment:data.a_id,
                        comment:$('#mdl_comment').val(),
                        status
                    }
                    // console.log(dataR);return;
                    $(this).simple_call_text(dataR,'url_change_status',false,(data) =>{
                        const rep = data.response;
                        if(rep.success == 1){

                                $(this).mensaje_alerta(2, 'Se proceso el servicio correctamente');

                                //filters tokens
                                const tokens = rep.tokens.map((item) => item.u_notify_code);
                                $(this).send_notify("Sys Aseo CR",`${noty_body} ${rep.name}`,tokens);
                                socket.emit("fills_form", rep);// Emitir el evento después de la acción

                        }else{
                            $(this).mensaje_alerta(1, rep.msg);
                        }
                        // window.location.reload();
                        return true;
                    },true);
                }
            })
        });
    }

    $.fn.change_status_hand = function (data) {
        return this.each(function () {


            Swal.fire({
                position: 'center-center',
                title: 'Ejecutar Tarea no molestar <i class="fas fa-hand text-danger"></i>',
                html: `Está seguro de cambiar la orden a no molestar<br>
                     <br>Filial: <b>${data.f_name}</b>
                     <br>Piso: <b>${data.fr_name}</b>
                     <br>Estado Actual: <b>${data.s_name}</b>
                `,
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Registrar no molestar',
                cancelButtonText: 'Cancelar',

            }).then((result) => {
                if (result.value) {

                    const dataR = {
                        filial: data.f_id,
                        assigment:data.a_id
                    }
                    $(this).simple_call_text(dataR,'url_change_status_hand',false,(err) =>{
                        // window.location.reload();
                        const rep = err.response;
                        if(rep.success == 1) {
                            socket.emit("fills_form", rep);// Emitir el evento después de la acción
                        }
                        return true;
                    },true);
                }
            })
        });
    }

    $.fn.clean_busy = function (data) {
        return this.each(function () {


            Swal.fire({
                position: 'center-center',
                title: 'Cambiar estado de la Tarea',
                html: `Está seguro de cambiar de cambiar el estado a <b>ocupada Limpia</b><br>
                     <br>Filial: <b>${data.f_name}</b>
                     <br>Piso: <b>${data.fr_name}</b>
                     <br>Estado Actual: <b>${data.s_name}</b>
                `,
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Cambiar Estado',
                cancelButtonText: 'Cancelar',

            }).then((result) => {
                if (result.value) {

                    const dataR = {
                        filial: data.f_id,
                        assigment:data.a_id
                    }
                    $(this).simple_call_text(dataR,'url_change_clean_busy',false,(err) =>{
                        // window.location.reload();
                        // socket.emit("fills_form", data);
                        const rep = err.response;
                        if(rep.success == 1) {
                            socket.emit("fills_form", rep);// Emitir el evento después de la acción
                        }
                        return true;
                    },true);
                }
            })
        });
    }

    // setInterval(function () {
    //     $("#all_filials").load(location.href+" #all_filials>*","");
    // }, 6500);
});