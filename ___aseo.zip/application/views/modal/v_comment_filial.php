<?php
defined('BASEPATH') or exit('No direct script access allowed');
$name          = $this->class_security->validate_var($datas,'u_name');
$atcreate      = $this->class_security->validate_var($datas,'hc_atcreate');
$comment      = $this->class_security->validate_var($datas,'hc_comment');
$fname      = $this->class_security->validate_var($datasComment,'f_name');

//Comment data
$c_name      = $this->class_security->validate_var($datasComment,'u_name');
$c_comment   = $this->class_security->validate_var($datasComment,'a_observation_clean');
$c_date      = $this->class_security->validate_var($datasComment,'a_ending');

?>

<form role="form" data-toggle="validator" method="POST" class="frm_data" id="frm_data">
    <input type="hidden" name="filial" value="<?=$id?>">
    <div class="modal-body">

        <?php
        if($this->user_data->u_profile != 4):
        ?>
        <h3>Comentario Recepción</h3>

        <div class="row mb-3">



            <div class="form-group col">
                <label>Usuario Creador</label>
                <input type="text" disabled autofocus value="<?=$name?>" class="form-control imput_reset" autocomplete="off">
            </div>

            <div class="form-group col">
                <label>Fecha Solicitud</label>
                <input type="text" disabled autofocus value="<?=$atcreate?>" class="form-control imput_reset" autocomplete="off">
            </div>


        </div>

        <div class="row mb-3">
            <div class="form-group col">
                <label>Comentario</label>
                <textarea rows="6" disabled autofocus class="form-control imput_reset" autocomplete="off"><?=$comment?></textarea>
            </div>

        </div>

        <?php
        else:
         ?>

       <div class="row mb-3">
                <div class="form-group col">
                    <label>Filial</label>
                    <input type="text" readonly name="fname" autofocus value="<?=$fname?>" class="form-control imput_reset" autocomplete="off">
                </div>

        </div>

            <div class="row mb-3">

                <div class="form-group col">
                    <label>Comentario</label>
                    <textarea rows="6" name="observation" autofocus required class="form-control imput_reset" autocomplete="off"><?=$comment?></textarea>
                </div>

            </div>

        <?php

            endif;

            if($this->user_data->u_profile != 3):
        ?>
        <hr>

        <h3>Ultimo Comentario de la tarea Asignada</h3>

        <div class="row mb-3">
            <div class="form-group col">
                <label>Usuario Creador</label>
                <input type="text" disabled autofocus value="<?=$c_name?>" class="form-control imput_reset" autocomplete="off">
            </div>


            <div class="form-group col">
                <label>Fecha Comentario</label>
                <input type="text" disabled autofocus value="<?=$c_date?>" class="form-control imput_reset" autocomplete="off">
            </div>


        </div>

        <div class="row mb-3">

            <div class="form-group col">
                <label>Comentario</label>
                <textarea rows="6" disabled autofocus class="form-control imput_reset" autocomplete="off"><?=$c_comment?></textarea>
            </div>

        </div>

        <?php
            endif;
        ?>

    </div>

    <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Cancelar Proceso</button>

        <?php
        if($this->user_data->u_profile == 4):
            ?>
        <button type="submit" class="btn btn-primary">Guardar </button>
        <?php
            endif;
        ?>
    </div>
</form>

<script>
    $(document).ready(function() {
        //remove size modal
        $(this).clear_modal_view('modal-1000');


        $('#frm_data').validator().on('submit', function(e) {
            if (e.isDefaultPrevented()) {
                $(this).mensaje_alerta(1, "El campo es obligatorio");
                return false;
            } else {
                e.preventDefault();
                $(this).simple_call('frm_data','url_save');
                return false;
            }
        })

    })
</script>

